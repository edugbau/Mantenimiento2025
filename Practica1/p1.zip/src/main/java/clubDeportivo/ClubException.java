package clubDeportivo;

public class ClubException extends Exception{
	public ClubException() {
		super();
	}
	public ClubException(String mensaje) {
		super(mensaje);
	}
}
